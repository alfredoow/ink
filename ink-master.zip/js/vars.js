//base
var ink = 0.0; //total ink
var money = 1.0; //money in $
var ips = 0.0; //ink per second

//converters
var inkmachineamount = 1; //how many ink machines there are
var inkmachinerate = 0.001; //how much ink the ink machines make per second
var inkmachineprice = 1.0; //price of buying more ink machines

//cartridges
var cartridgeammount = 1; //how many cartridges there are
var cartridgesize = 0.01; //size of each cartridge
var cartridgeupgrade = 10; //price of upgrading cartridge size
var cartridgeprice = 1.50;
var totalsize = cartridgesize * cartridgeammount; //total storage size